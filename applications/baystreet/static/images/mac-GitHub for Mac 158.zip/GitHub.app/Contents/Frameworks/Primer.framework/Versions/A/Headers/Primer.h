//
//  Primer.h
//  Primer
//
//  Created by Justin Spahr-Summers on 2013-07-01.
//  Copyright (c) 2013 GitHub. All rights reserved.
//

#ifdef __IPHONE_OS_VERSION_MIN_REQUIRED
	#import "UIFont+PRIStyleAdditions.h"
#elif TARGET_OS_MAC
	#import "NSFont+PRIStyleAdditions.h"
	#import "NSImage+PRIAdditions.h"
#endif
