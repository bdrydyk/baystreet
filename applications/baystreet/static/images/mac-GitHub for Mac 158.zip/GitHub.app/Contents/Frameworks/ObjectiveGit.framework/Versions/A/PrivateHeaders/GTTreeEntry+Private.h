//
//  GTTreeEntry+Private.h
//  ObjectiveGitFramework
//
//  Created by Etienne on 10/07/13.
//  Copyright (c) 2013 GitHub, Inc. All rights reserved.
//

#import <ObjectiveGit/ObjectiveGit.h>

@interface GTTreeEntry ()
- (GTObjectType)type;
@end
